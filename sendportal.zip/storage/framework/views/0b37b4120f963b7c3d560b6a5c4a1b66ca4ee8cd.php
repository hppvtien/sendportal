<ul class="nav nav-pills mb-4">
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('sendportal.campaigns.index') ? 'active'  : ''); ?>"
           href="<?php echo e(route('sendportal.campaigns.index')); ?>"><?php echo e(__('Chưa gửi')); ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('sendportal.campaigns.sent') ? 'active'  : ''); ?>"
           href="<?php echo e(route('sendportal.campaigns.sent')); ?>"><?php echo e(__('Đã gửi')); ?></a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/partials/nav.blade.php ENDPATH**/ ?>