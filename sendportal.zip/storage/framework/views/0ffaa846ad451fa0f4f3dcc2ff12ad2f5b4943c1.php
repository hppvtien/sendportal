<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger">
                <p class="font-weight-bold mb-1"><?php echo e(__('Error!')); ?></p>
                <p class="mb-0"><?php echo e(session()->get('error')); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/error.blade.php ENDPATH**/ ?>