<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <p class="font-weight-bold mb-1"><?php echo e(__('Success!')); ?></p>
                <p class="mb-0"><?php echo e(session()->get('success')); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/success.blade.php ENDPATH**/ ?>