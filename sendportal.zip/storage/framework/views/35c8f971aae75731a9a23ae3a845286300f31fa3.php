<?php if (isset($component)) { $__componentOriginalb9f8afb19f630cf35b68b017a64bdd0e82dcc5be = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\FieldWrapper::class, ['name' => $name,'label' => $label]); ?>
<?php $component->withName('sendportal.field-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <select name="<?php echo e($name); ?>" <?php echo e($attributes->merge(['id' => 'id-field-' .  str_replace('[]', '', $name), 'class' => 'form-control ' . ($multiple ? 'selectpicker' : ''), 'multiple' => $multiple])); ?>>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($isSelected($key) ? 'selected' : ''); ?>><?php echo e($text); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9f8afb19f630cf35b68b017a64bdd0e82dcc5be)): ?>
<?php $component = $__componentOriginalb9f8afb19f630cf35b68b017a64bdd0e82dcc5be; ?>
<?php unset($__componentOriginalb9f8afb19f630cf35b68b017a64bdd0e82dcc5be); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/components/select-field.blade.php ENDPATH**/ ?>