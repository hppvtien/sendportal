<div <?php echo e($attributes->merge(['class' => 'form-group row form-group-' . $name . ' ' . $wrapperClass  . ' '. $errorClass($name)])); ?>>
    <?php if (isset($component)) { $__componentOriginala562e65cde527945a7b85435d43f2f60e9a05515 = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\Label::class, ['name' => $name]); ?>
<?php $component->withName('sendportal.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($label); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala562e65cde527945a7b85435d43f2f60e9a05515)): ?>
<?php $component = $__componentOriginala562e65cde527945a7b85435d43f2f60e9a05515; ?>
<?php unset($__componentOriginala562e65cde527945a7b85435d43f2f60e9a05515); ?>
<?php endif; ?>
    <div class="col-sm-9">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/components/field-wrapper.blade.php ENDPATH**/ ?>