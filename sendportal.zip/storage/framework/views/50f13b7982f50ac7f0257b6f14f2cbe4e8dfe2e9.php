<div class="d-flex flex-column flex-md-row justify-content-between mb-3">
    <div>
        <?php echo e($left ?? ''); ?>

    </div>
    <div>
        <?php echo e($right ?? ''); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/actions.blade.php ENDPATH**/ ?>