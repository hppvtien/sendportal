<div class="main-wrapper col p-0 min-vh-100">

    <div class="main-content pl-4-half pr-4-half pb-4-half pt-4">

        <div class="alert-success"></div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
            </div>
        </div>
        <div class="d-flex flex-column flex-md-row justify-content-between mb-3">
        
                <form action="http://127.0.0.1:8000/subscribers" method="GET" class="form-inline mb-3 mb-md-0">
                    <input class="form-control form-control-sm" name="name" type="text" value=""
                        placeholder="Search...">

                    <div class="mr-2">
                        <select name="status" class="form-control form-control-sm">
                            <option value="all">All</option>
                            <option value="subscribed" selected="">Subscribed</option>
                            <option value="unsubscribed">Unsubscribed</option>
                        </select>
                    </div>

                    <button type="button" class="btn btn-light btn-md">Search</button>

                    <a href="javascript:;" class="btn btn-md btn-light">Clear</a>
                </form>
           

        </div>
        <div class="card">
            <div class="card-table table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Chọn</th>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $subscriber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><input type="checkbox" name="subscriibers_id" value="<?php echo e($subscriber->id); ?>" class="message-select"
                                    form="send-selected-form"></td>
                            <td>
                                <a href="javascript:;">
                                    <?php echo e($subscriber->email); ?>

                                </a>
                            </td>
                            <td><?php echo e($subscriber->first_name); ?> <?php echo e($subscriber->last_name); ?></td>
                            <td><span title="2021-06-08 08:27:13"><?php echo e($subscriber->created_at); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/get_subscribers.blade.php ENDPATH**/ ?>