<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->ownsCurrentWorkspace()): ?>
        <li class="nav-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                <i class="fa-fw fas fa-users mr-2"></i><span><?php echo e(__('Quản lý người dùng')); ?></span>
            </a>
        </li>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/layouts/sidebar/manageUsersMenuItem.blade.php ENDPATH**/ ?>