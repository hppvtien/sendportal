<?php if(isset($errors) and $errors->any()): ?>
    <div class="row">
        <div class="col-lg-6 offset-lg-3">
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/errors.blade.php ENDPATH**/ ?>