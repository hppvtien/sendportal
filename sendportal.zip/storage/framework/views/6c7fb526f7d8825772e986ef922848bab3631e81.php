<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <?php if(session()->has('warning')): ?>
            <div class="alert alert-warning">
                <p class="font-weight-bold mb-1"><?php echo e(__('Warning!')); ?></p>
                <p class="mb-0"><?php echo e(session()->get('warning')); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/warning.blade.php ENDPATH**/ ?>