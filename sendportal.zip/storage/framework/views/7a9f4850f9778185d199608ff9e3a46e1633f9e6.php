

<?php $__env->startSection('title', __('Tạo chiến dịch')); ?>

<?php $__env->startSection('heading', __('Chiến dịch')); ?>

<?php $__env->startSection('content'); ?>

    <?php if( ! $emailServices): ?>
        <div class="callout callout-danger">
            <h4><?php echo e(__('You haven\'t added any email service!')); ?></h4>
            <p><?php echo e(__('Before you can create a campaign, you must first')); ?> <a
                    href="<?php echo e(route('sendportal.email_services.create')); ?>"><?php echo e(__('add an email service')); ?></a>.
            </p>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(__('Tạo chiến dịch')); ?>

                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('sendportal.campaigns.store')); ?>" method="POST" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('sendportal::campaigns.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sendportal::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/create.blade.php ENDPATH**/ ?>