

<?php $__env->startSection('title', __('Chiến dịch')); ?>

<?php $__env->startSection('heading'); ?>
    <?php echo e(__('Chiến dịch')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('sendportal::campaigns.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startComponent('sendportal::layouts.partials.actions'); ?>
        <?php $__env->slot('right'); ?>
            <a class="btn btn-primary btn-md btn-flat" href="<?php echo e(route('sendportal.campaigns.create')); ?>">
                <i class="fa fa-plus mr-1"></i> <?php echo e(__('Thêm mới chiến dịch')); ?>

            </a>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="card">
        <div class="card-table table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th><?php echo e(__('Name')); ?></th>
                    <?php if(request()->routeIs('sendportal.campaigns.sent')): ?>
                        <th><?php echo e(__('Sent')); ?></th>
                        <th><?php echo e(__('Opened')); ?></th>
                        <th><?php echo e(__('Clicked')); ?></th>
                    <?php endif; ?>
                    <th><?php echo e(__('Tạo cách đây')); ?></th>
                    <th><?php echo e(__('Trạng thái')); ?></th>
                    <th><?php echo e(__('Actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($campaign->draft): ?>
                                <a href="<?php echo e(route('sendportal.campaigns.edit', $campaign->id)); ?>"><?php echo e($campaign->name); ?></a>
                            <?php elseif($campaign->sent): ?>
                                <a href="<?php echo e(route('sendportal.campaigns.reports.index', $campaign->id)); ?>"><?php echo e($campaign->name); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('sendportal.campaigns.status', $campaign->id)); ?>"><?php echo e($campaign->name); ?></a>
                            <?php endif; ?>
                        </td>
                        <?php if(request()->routeIs('sendportal.campaigns.sent')): ?>
                            <td><?php echo e($campaignStats[$campaign->id]['counts']['sent']); ?></td>
                            <td><?php echo e(number_format($campaignStats[$campaign->id]['ratios']['open'] * 100, 1) . '%'); ?></td>
                            <td>
                                <?php echo e(number_format($campaignStats[$campaign->id]['ratios']['click'] * 100, 1) . '%'); ?>

                            </td>
                        <?php endif; ?>
                        <td><span title="<?php echo e($campaign->created_at); ?>"><?php echo e($campaign->created_at->diffForHumans()); ?></span></td>
                        <td>
                            <?php echo $__env->make('sendportal::campaigns.partials.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-light btn-sm btn-wide" type="button" id="dropdownMenuButton"
                                        data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-ellipsis-h"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php if($campaign->draft): ?>
                                        <a href="<?php echo e(route('sendportal.campaigns.edit', $campaign->id)); ?>"
                                           class="dropdown-item">
                                            <?php echo e(__('Sửa')); ?>

                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('sendportal.campaigns.reports.index', $campaign->id)); ?>"
                                           class="dropdown-item">
                                            <?php echo e(__('Thống kê')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('sendportal.campaigns.duplicate', $campaign->id)); ?>"
                                       class="dropdown-item">
                                        <?php echo e(__('Nhân bản chiến dịch')); ?>

                                    </a>

                                    <?php if($campaign->canBeCancelled()): ?>
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo e(route('sendportal.campaigns.confirm-cancel', $campaign->id)); ?>"
                                           class="dropdown-item">
                                            <?php echo e(__('Cancel')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if($campaign->draft): ?>
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo e(route('sendportal.campaigns.destroy.confirm', $campaign->id)); ?>"
                                           class="dropdown-item">
                                            <?php echo e(__('Delete')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="100%">
                            <p class="empty-table-text">
                                <?php if(request()->routeIs('sendportal.campaigns.index')): ?>
                                    <?php echo e(__('You do not have any draft campaigns.')); ?>

                                <?php else: ?>
                                    <?php echo e(__('You do not have any sent campaigns.')); ?>

                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php echo $__env->make('sendportal::layouts.partials.pagination', ['records' => $campaigns], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('sendportal::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/index.blade.php ENDPATH**/ ?>