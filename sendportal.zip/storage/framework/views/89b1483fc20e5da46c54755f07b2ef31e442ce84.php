

<?php $__env->startSection('title', __('Dashboard')); ?>

<?php $__env->startSection('heading'); ?>
    <?php echo e(__('Dashboard')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header card-header-accent">
                    <div class="card-header-inner">
                        <?php echo e(__('Total Subscribers')); ?>

                    </div>
                </div>
                <div class="card-body">
                    <div style="width: 99%;">
                        <canvas id="growthChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header card-header-accent">
                    <div class="card-header-inner">
                        <?php echo e(__('Completed Campaigns')); ?>

                    </div>
                </div>
                <div class="card-table table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th><?php echo e(__('Name')); ?></th>
                            <th><?php echo e(__('Sent')); ?></th>
                            <th><?php echo e(__('Opened')); ?></th>
                            <th><?php echo e(__('Clicked')); ?></th>
                            <th><?php echo e(__('Created')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $completedCampaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if($campaign->draft): ?>
                                        <a href="<?php echo e(route('sendportal.campaigns.edit', $campaign->id)); ?>"><?php echo e($campaign->name); ?></a>
                                    <?php elseif($campaign->sent): ?>
                                        <a href="<?php echo e(route('sendportal.campaigns.reports.index', $campaign->id)); ?>"><?php echo e($campaign->name); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('sendportal.campaigns.status', $campaign->id)); ?>"><?php echo e($campaign->name); ?></a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($campaignStats[$campaign->id]['counts']['sent']); ?></td>
                                <td><?php echo e(number_format($campaignStats[$campaign->id]['ratios']['open'] * 100, 1) . '%'); ?></td>
                                <td><?php echo e(number_format($campaignStats[$campaign->id]['ratios']['click'] * 100, 1) . '%'); ?></td>
                                <td><span title="<?php echo e($campaign->created_at); ?>"><?php echo e($campaign->created_at->diffForHumans()); ?></span></td>
                                <td>
                                    <?php echo $__env->make('sendportal::campaigns.partials.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-light btn-sm btn-wide" type="button"
                                                id="dropdownMenuButton"
                                                data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true"
                                                aria-expanded="false">
                                            <i class="fas fa-ellipsis-h"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <?php if($campaign->draft): ?>
                                                <a href="<?php echo e(route('sendportal.campaigns.edit', $campaign->id)); ?>"
                                                   class="dropdown-item">
                                                    <?php echo e(__('Edit')); ?>

                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('sendportal.campaigns.reports.index', $campaign->id)); ?>"
                                                   class="dropdown-item">
                                                    <?php echo e(__('View Report')); ?>

                                                </a>
                                            <?php endif; ?>

                                            <a href="<?php echo e(route('sendportal.campaigns.duplicate', $campaign->id)); ?>"
                                               class="dropdown-item">
                                                <?php echo e(__('Duplicate')); ?>

                                            </a>

                                            <?php if($campaign->draft): ?>
                                                <div class="dropdown-divider"></div>
                                                <a href="<?php echo e(route('sendportal.campaigns.destroy.confirm', $campaign->id)); ?>"
                                                   class="dropdown-item">
                                                    <?php echo e(__('Delete')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%">
                                    <p class="empty-table-text"><?php echo e(__('You have not completed any campaigns.')); ?></p>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header card-header-accent">
                    <div class="card-header-inner">
                        <?php echo e(__('Recent Subscribers')); ?>

                    </div>
                </div>
                <div class="card-table table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th><?php echo e(__('Email')); ?></th>
                            <th><?php echo e(__('Name')); ?></th>
                            <th><?php echo e(__('Created')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentSubscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('sendportal.subscribers.show', $subscriber->id)); ?>">
                                        <?php echo e($subscriber->email); ?>

                                    </a>
                                </td>
                                <td><?php echo e($subscriber->full_name); ?></td>
                                <td><span
                                        title="<?php echo e($subscriber->created_at); ?>"><?php echo e($subscriber->created_at->diffForHumans()); ?></span>
                                </td>
                                <td>
                                    <?php if($subscriber->unsubscribed_at): ?>
                                        <span class="badge badge-danger"><?php echo e(__('Unsubscribed')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-success"><?php echo e(__('Subscribed')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><a href="<?php echo e(route('sendportal.subscribers.edit', $subscriber->id)); ?>"
                                       class="btn btn-sm btn-light"><?php echo e(__('Edit')); ?></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%">
                                    <p class="empty-table-text"><?php echo e(__('No recent subscribers.')); ?></p>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>

    <script>
        $(function () {
            var ctx = document.getElementById("growthChart");
            ctx.height = 300;
            var subscriberGrowthChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo $subscriberGrowthChartLabels; ?>,
                    datasets: [{
                        data: <?php echo $subscriberGrowthChartData; ?>,
                        label: "<?php echo e(__("Subscriber Count")); ?>",
                        borderColor: 'rgba(93,99,255)',
                        backgroundColor: 'rgba(93,99,255,0.34)',
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            gridLines: {
                                display: false
                            }
                        }],
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                precision: 0,
                                suggestedMax: 10
                            }
                        }]
                    },
                    tooltips: {
                        intersect: false
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('sendportal::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/dashboard/index.blade.php ENDPATH**/ ?>