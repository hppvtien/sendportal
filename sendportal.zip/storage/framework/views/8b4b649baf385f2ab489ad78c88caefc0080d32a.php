<?php if($campaign->draft): ?>
    <span class="badge badge-light"><?php echo e($campaign->status->name); ?></span>
<?php elseif($campaign->queued): ?>
    <span class="badge badge-warning"><?php echo e($campaign->status->name); ?></span>
<?php elseif($campaign->sending): ?>
    <span class="badge badge-warning"><?php echo e($campaign->status->name); ?></span>
<?php elseif($campaign->sent): ?>
    <span class="badge badge-success"><?php echo e($campaign->status->name); ?></span>
<?php elseif($campaign->cancelled): ?>
    <span class="badge badge-danger"><?php echo e($campaign->status->name); ?></span>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/partials/status.blade.php ENDPATH**/ ?>