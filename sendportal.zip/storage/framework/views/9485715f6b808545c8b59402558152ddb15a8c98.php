<div class="sidebar-inner mx-3">
    <ul class="nav flex-column mt-4">
        <li class="nav-item <?php echo e(request()->routeIs('sendportal.dashboard') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.dashboard')); ?>">
                <i class="fa-fw fas fa-home mr-2"></i><span><?php echo e(__('Dashboard')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(request()->is('*campaigns*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.campaigns.index')); ?>">
                <i class="fa-fw fas fa-envelope mr-2"></i><span><?php echo e(__('Chiến dịch')); ?></span>
            </a>
        </li>
        <?php if(\Sendportal\Base\Facades\Helper::isPro()): ?>
        <li class="nav-item <?php echo e(request()->is('*automations*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.automations.index')); ?>">
                <i class="fa-fw fas fa-sync-alt mr-2"></i><span><?php echo e(__('Automations')); ?></span>
            </a>
        </li>
        <?php endif; ?>
        <li class="nav-item <?php echo e(request()->is('*templates*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.templates.index')); ?>">
                <i class="fa-fw fas fa-file-alt mr-2"></i><span><?php echo e(__('Templates')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(request()->is('*subscribers*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.subscribers.index')); ?>">
                <i class="fa-fw fas fa-user mr-2"></i><span><?php echo e(__('Đăng ký nhận mail')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(request()->is('*messages*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.messages.index')); ?>">
                <i class="fa-fw fas fa-paper-plane mr-2"></i><span><?php echo e(__('Trạng thái mail')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(request()->is('*email-services*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sendportal.email_services.index')); ?>">
                <i class="fa-fw fas fa-envelope mr-2"></i><span><?php echo e(__('Dịch vụ mail')); ?></span>
            </a>
        </li>

        <?php echo \Sendportal\Base\Facades\Sendportal::sidebarHtmlContent(); ?>


    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/sidebar.blade.php ENDPATH**/ ?>