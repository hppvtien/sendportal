<?php if(auth()->guard()->check()): ?>
    <ul class="navbar-nav flex-row ml-md-auto d-md-flex">
        <?php $workspaces = auth()->user()->workspaces ?>

        <?php if(count($workspaces) == 1): ?>
            <li class="nav-item mr-5 px-2">
            <span class="nav-link" id="bd-versions" aria-haspopup="true" aria-expanded="false">
                 <?php echo e(auth()->user()->currentWorkspace->name); ?>

            </span>
            </li>
        <?php elseif(count($workspaces) > 1 && auth()->user()->currentWorkspace): ?>
            <li class="nav-item dropdown mr-4 px-2 workspace-select">
                <a class="nav-link dropdown-toggle color-purple-500" href="#" id="bd-versions"
                   data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    <?php echo e(auth()->user()->currentWorkspace->name); ?><i class="ml-2 fas fa-caret-down color-gray-500"></i>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                    <?php $__currentLoopData = $workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item px-3" href="<?php echo e(route('workspaces.switch', $workspace->id)); ?>">
                            <i class="fas fa-circle mr-2 <?php echo e(auth()->user()->currentWorkspace->id == $workspace->id ? 'color-purple-500' : 'color-gray-300'); ?>"></i><?php echo e($workspace->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </li>
        <?php endif; ?>

        <li class="nav-item dropdown pl-3 user-dropdown">

            <a class="nav-link dropdown-toggle mr-md-1 color-purple-500" href="#" id="bd-versions"
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
               title="<?php echo e(auth()->user()->full_name); ?>">
                <img src="<?php echo e(auth()->user()->avatar); ?>" height="25" class="rounded-circle mr-2"
                     alt="<?php echo e(auth()->user()->name); ?>">
                <span class="d-none d-sm-inline-block"><?php echo e(\Illuminate\Support\Str::limit( auth()->user()->name, 25)); ?></span>
                <i
                        class="ml-2 fas fa-caret-down color-gray-500"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">

                
                <a class="dropdown-item px-3" href="<?php echo e(route('profile.show')); ?>"><i
                            class="fas fa-user mr-2 color-gray-300"></i><?php echo e(__('Thông tin cá nhân')); ?></a>

                
                <!-- <a class="dropdown-item px-3" href="<?php echo e(route('workspaces.index')); ?>"><i
                            class="fas fa-layer-group mr-2 color-gray-300"></i><?php echo e(__('Không gian')); ?></a> -->

                
                <!-- <a class="dropdown-item px-3" href="<?php echo e(route('api-tokens.index')); ?>"><i
                            class="fas fa-layer-group mr-2 color-gray-300"></i><?php echo e(__('API Tokens')); ?></a> -->

                <div class="dropdown-divider"></div>
                <a class="dropdown-item px-3" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                            class="fas fa-sign-out-alt mr-2 color-gray-300"></i>Đăng xuất</a>
            </div>
        </li>
    </ul>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/layouts/header/userManagementHeader.blade.php ENDPATH**/ ?>