<?php if (isset($component)) { $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\TextField::class, ['name' => 'name','label' => __('Tên chiến dịch'),'value' => $campaign->name ?? old('name')]); ?>
<?php $component->withName('sendportal.text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b)): ?>
<?php $component = $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b; ?>
<?php unset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\TextField::class, ['name' => 'subject','label' => __('Chủ đề'),'value' => $campaign->subject ?? old('subject')]); ?>
<?php $component->withName('sendportal.text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b)): ?>
<?php $component = $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b; ?>
<?php unset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\TextField::class, ['name' => 'from_name','label' => __('Tên người gửi'),'value' => $campaign->from_name ?? old('from_name')]); ?>
<?php $component->withName('sendportal.text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b)): ?>
<?php $component = $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b; ?>
<?php unset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\TextField::class, ['name' => 'from_email','label' => __('Email gửi'),'type' => 'email','value' => $campaign->from_email ?? old('from_email')]); ?>
<?php $component->withName('sendportal.text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b)): ?>
<?php $component = $__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b; ?>
<?php unset($__componentOriginalc9b653d374a97b1f2e7a3a981ff7d15458f1812b); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\SelectField::class, ['name' => 'template_id','label' => __('Chọn giao diện mail'),'options' => $templates,'value' => $campaign->template_id ?? old('template_id')]); ?>
<?php $component->withName('sendportal.select-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4)): ?>
<?php $component = $__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4; ?>
<?php unset($__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\SelectField::class, ['name' => 'email_service_id','label' => __('Dịch vụ gửi email'),'options' => $emailServices->pluck('formatted_name', 'id'),'value' => $campaign->email_service_id ?? old('email_service_id')]); ?>
<?php $component->withName('sendportal.select-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4)): ?>
<?php $component = $__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4; ?>
<?php unset($__componentOriginalc46a0d819eec437c02d05fc772eaa50fcc8a59d4); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22 = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\CheckboxField::class, ['name' => 'is_open_tracking','label' => __('Track Opens'),'value' => '1','checked' => $campaign->is_open_tracking ?? true]); ?>
<?php $component->withName('sendportal.checkbox-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22)): ?>
<?php $component = $__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22; ?>
<?php unset($__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22 = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\CheckboxField::class, ['name' => 'is_click_tracking','label' => __('Track Clicks'),'value' => '1','checked' => $campaign->is_click_tracking ?? true]); ?>
<?php $component->withName('sendportal.checkbox-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22)): ?>
<?php $component = $__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22; ?>
<?php unset($__componentOriginale5cc56de7335e3561979ed8824be344e0ea51d22); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginaleae951fde062a3809d181541a92d2ef9426886b8 = $component; } ?>
<?php $component = $__env->getContainer()->make(Sendportal\Base\View\Components\TextareaField::class, ['name' => 'content','label' => __('Nội dung')]); ?>
<?php $component->withName('sendportal.textarea-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($campaign->content ?? old('content')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleae951fde062a3809d181541a92d2ef9426886b8)): ?>
<?php $component = $__componentOriginaleae951fde062a3809d181541a92d2ef9426886b8; ?>
<?php unset($__componentOriginaleae951fde062a3809d181541a92d2ef9426886b8); ?>
<?php endif; ?>

<div class="form-group row">
    <div class="offset-sm-3 col-sm-9">
        <a href="<?php echo e(route('sendportal.campaigns.index')); ?>" class="btn btn-light"><?php echo e(__('Cancel')); ?></a>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Lưu và tiếp tục')); ?></button>
    </div>
</div>

<?php echo $__env->make('sendportal::layouts.partials.summernote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('js'); ?>
    <script>

        $(function () {
            const smtp = <?php echo e($emailServices->filter(function ($service) {
                    return $service->type_id === \Sendportal\Base\Models\EmailServiceType::SMTP;
                })
                ->pluck('id')); ?>;

            let service_id = $('select[name="email_service_id"]').val();

            toggleTracking(smtp.includes(parseInt(service_id, 10)));

            $('select[name="email_service_id"]').on('change', function () {
              toggleTracking(smtp.includes(parseInt(this.value, 10)));
            });
        });

        function toggleTracking(disable) {
            let $open = $('input[name="is_open_tracking"]');
            let $click = $('input[name="is_click_tracking"]');

            if (disable) {
                $open.attr('disabled', 'disabled');
                $click.attr('disabled', 'disabled');
            } else {
                $open.removeAttr('disabled');
                $click.removeAttr('disabled');
            }
        }

    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/partials/form.blade.php ENDPATH**/ ?>