<div class="logo text-center">
    <img src="<?php echo e(asset('/vendor/sendportal/img/logo-main.png')); ?>" alt="SendPortal" width="225px" class="my-5">
</div>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/auth/partials/logo.blade.php ENDPATH**/ ?>