

<?php $__env->startSection('htmlBody'); ?>
    <div class="container-fluid">
        <div class="row">

            <div class="sidebar bg-purple-100 min-vh-100 d-none d-xl-block">

                <div class="mt-4">
                    <div class="logo text-center">
                        <a href="<?php echo e(route('sendportal.dashboard')); ?>">
                            <img src="<?php echo e(asset('/vendor/sendportal/img/logo-main.png')); ?>" alt="" width="80px">
                        </a>
                    </div>
                </div>

                <div class="mt-5">
                    <?php echo $__env->make('sendportal::layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <?php echo $__env->make('sendportal::layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sendportal::layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/app.blade.php ENDPATH**/ ?>