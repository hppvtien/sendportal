<div class="row mb-4">
    <div class="col-sm-6">
        <?php echo $records->links(); ?>

    </div>
    <div class="col-sm-6 text-right pt-1">
        <?php echo e(__('Showing :count of :total items', ['count' => $records->count(), 'total' => $records->total()])); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/layouts/partials/pagination.blade.php ENDPATH**/ ?>