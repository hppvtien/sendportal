

<?php $__env->startSection('title', __('Delete Campaign')); ?>

<?php $__env->startSection('heading'); ?>
    <?php echo app('translator')->get('Delete Campaign'); ?> - <?php echo e($campaign->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('sendportal::layouts.partials.actions'); ?>
        <?php $__env->slot('right'); ?>
            <a class="btn btn-primary btn-md btn-flat" href="<?php echo e(route('sendportal.campaigns.create')); ?>">
                <i class="fa fa-plus mr-1"></i> <?php echo e(__('Create Campaign')); ?>

            </a>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="card">
        <div class="card-header card-header-accent">
            <div class="card-header-inner">
                <?php echo e(__('Confirm Delete')); ?>

            </div>
        </div>
        <div class="card-body">
            <p>
                <?php echo __('Are you sure that you want to delete the <b>:name</b> campaign?', ['name' => $campaign->name]); ?>

            </p>
            <form action="<?php echo e(route('sendportal.campaigns.destroy', $campaign->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="hidden" name="id" value="<?php echo e($campaign->id); ?>">
                <a href="<?php echo e(route('sendportal.campaigns.index')); ?>" class="btn btn-md btn-light"><?php echo e(__('Cancel')); ?></a>
                <button type="submit" class="btn btn-md btn-danger"><?php echo e(__('DELETE')); ?></button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('sendportal::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_maketing\sendportal\resources\views/vendor/sendportal/campaigns/delete.blade.php ENDPATH**/ ?>